const $ = s => document.querySelector(s);
const api = async (url, options={}) => {
  const token = localStorage.getItem("token");
  options.headers = {"Content-Type":"application/json", ...(options.headers||{})};
  if(token) options.headers.Authorization = "Bearer " + token;
  const r = await fetch(url, options);
  const data = await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error || "请求失败");
  return data;
};

let user = null;
let authMode = "login";
let level = "medium";
let game = null;
let timerId = null;

const levels = {
  easy:{w:9,h:9,mines:10},
  medium:{w:16,h:16,mines:40},
  hard:{w:30,h:16,mines:99}
};

function showModal(mode="login"){
  authMode=mode;
  $("#authTitle").textContent=mode==="login"?"登录":"注册";
  $("#submitAuth").textContent=mode==="login"?"登录":"注册";
  $("#switchAuth").textContent=mode==="login"?"没有账号？注册一个":"已有账号？返回登录";
  $("#authMessage").textContent="";
  $("#authModal").classList.remove("hidden");
}
function renderAccount(){
  $("#accountArea").innerHTML = user
    ? `<span class="user-pill">👤 ${escapeHtml(user.username)} · 胜场 ${user.wins}</span><button class="btn" id="logout">退出</button>`
    : `<button class="btn primary" id="loginBtn">登录 / 注册</button>`;
  if($("#loginBtn")) $("#loginBtn").onclick=()=>showModal("login");
  if($("#logout")) $("#logout").onclick=()=>{localStorage.removeItem("token");user=null;renderAccount();};
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

$("#closeModal").onclick=()=>$("#authModal").classList.add("hidden");
$("#switchAuth").onclick=()=>showModal(authMode==="login"?"register":"login");
$("#authForm").onsubmit=async e=>{
  e.preventDefault();
  const username=$("#username").value.trim(), password=$("#password").value;
  try{
    const data=await api(authMode==="login"?"/api/login":"/api/register",{method:"POST",body:JSON.stringify({username,password})});
    localStorage.setItem("token",data.token); user=data.user; renderAccount();
    $("#authModal").classList.add("hidden");
  }catch(err){$("#authMessage").textContent=err.message}
};

async function loadUser(){
  if(!localStorage.getItem("token")) return;
  try{user=await api("/api/me")}catch{localStorage.removeItem("token");user=null}
  renderAccount();
}
async function loadLeaderboard(){
  try{
    const list=await api("/api/leaderboard");
    $("#leaderboardList").innerHTML=list.length?list.map(x=>`<div class="rank"><span class="rank-num">${medal(x.rank)} ${x.rank}</span><span>${escapeHtml(x.username)}</span><span class="wins">${x.wins} 胜</span></div>`).join(""):"暂无玩家，快来成为第一名！";
  }catch(e){$("#leaderboardList").textContent="排行榜加载失败"}
}
function medal(n){return n===1?"🥇":n===2?"🥈":n===3?"🥉":"🏅"}

function startGame(){
  clearInterval(timerId);
  const cfg=levels[level];
  game={w:cfg.w,h:cfg.h,mines:cfg.mines,started:false,over:false,win:false,flagged:0,elapsed:0,cells:[]};
  $("#mineCount").textContent=cfg.mines;
  $("#timer").textContent=0;
  $("#status").textContent="准备开始";
  const board=$("#board");
  board.style.gridTemplateColumns=`repeat(${cfg.w}, 29px)`;
  board.innerHTML="";
  for(let y=0;y<cfg.h;y++) for(let x=0;x<cfg.w;x++){
    const c={x,y,mine:false,open:false,flag:false,n:0};
    game.cells.push(c);
    const b=document.createElement("button"); b.className="cell";
    b.oncontextmenu=e=>{e.preventDefault();toggleFlag(c,b)};
    b.onclick=()=>openCell(c,b);
    board.appendChild(b);
  }
}
function neighbors(c){
  const out=[];
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
    if(!dx&&!dy)continue;
    const x=c.x+dx,y=c.y+dy;
    if(x>=0&&x<game.w&&y>=0&&y<game.h) out.push(game.cells[y*game.w+x]);
  }
  return out;
}
function plantMines(safe){
  let pool=game.cells.filter(c=>c!==safe&&!neighbors(safe).includes(c));
  for(let i=pool.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]]}
  pool.slice(0,game.mines).forEach(c=>c.mine=true);
  game.cells.forEach(c=>c.n=neighbors(c).filter(n=>n.mine).length);
}
function openCell(c,b){
  if(game.over||c.flag||c.open)return;
  if(!game.started){
    plantMines(c);game.started=true;$("#status").textContent="游戏进行中";
    timerId=setInterval(()=>{$("#timer").textContent=++game.elapsed},1000);
  }
  c.open=true;b.classList.add("open");
  if(c.mine){b.textContent="💣";b.classList.add("mine");endGame(false);return}
  if(c.n){b.textContent=c.n;b.classList.add("n"+Math.min(c.n,5))}
  else neighbors(c).forEach(n=>{if(!n.open)openCell(n,document.querySelectorAll(".cell")[n.y*game.w+n.x])});
  checkWin();
}
function toggleFlag(c,b){
  if(game.over||c.open)return;
  c.flag=!c.flag;b.classList.toggle("flag",c.flag);b.textContent=c.flag?"🚩":"";
  game.flagged += c.flag?1:-1;
  $("#mineCount").textContent=Math.max(0,game.mines-game.flagged);
}
function endGame(win){
  game.over=true;clearInterval(timerId);
  if(win){game.win=true;$("#status").textContent="🎉 胜利！"}
  else{
    $("#status").textContent="💥 踩雷了";
    game.cells.forEach(c=>{if(c.mine&&!c.flag){const b=document.querySelectorAll(".cell")[c.y*game.w+c.x];b.textContent="💣";b.classList.add("mine")}});
  }
}
async function checkWin(){
  if(game.cells.every(c=>c.mine||c.open)){
    endGame(true);
    if(!user){
      setTimeout(()=>showModal("login"),300);
      return;
    }
    try{
      const data=await api("/api/win",{method:"POST"});
      user.wins=data.wins;renderAccount();loadLeaderboard();
    }catch(e){$("#status").textContent="胜利，但计分失败："+e.message}
  }
}
document.querySelectorAll(".difficulty button").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".difficulty button").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");level=btn.dataset.level;startGame();
});
$("#refreshBtn").onclick=loadLeaderboard;
loadUser();loadLeaderboard();startGame();