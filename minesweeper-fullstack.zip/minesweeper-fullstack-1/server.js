const express = require("express");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "change-this-secret-in-production";
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [] }, null, 2));

function readDB() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}
function makeToken(user) {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: "30d" });
}
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return res.status(401).json({ error: "请先登录" });
  try {
    req.user = jwt.verify(h.slice(7), JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "登录状态已失效，请重新登录" });
  }
}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/register", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[\w\u4e00-\u9fff-]{2,20}$/u.test(username))
    return res.status(400).json({ error: "用户名需要 2-20 个字符，只能包含中文、字母、数字、下划线或连字符" });
  if (password.length < 6 || password.length > 72)
    return res.status(400).json({ error: "密码长度需要 6-72 个字符" });

  const db = readDB();
  if (db.users.some(u => u.username.toLowerCase() === username.toLowerCase()))
    return res.status(409).json({ error: "这个用户名已经注册过了" });

  const user = {
    id: cryptoRandomId(),
    username,
    passwordHash: await bcrypt.hash(password, 10),
    wins: 0,
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  writeDB(db);
  res.json({ token: makeToken(user), user: { id: user.id, username: user.username, wins: user.wins } });
});

app.post("/api/login", async (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const db = readDB();
  const user = db.users.find(u => u.username.toLowerCase() === username.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.passwordHash)))
    return res.status(401).json({ error: "用户名或密码错误" });

  res.json({ token: makeToken(user), user: { id: user.id, username: user.username, wins: user.wins } });
});

app.get("/api/me", auth, (req, res) => {
  const db = readDB();
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "账号不存在" });
  res.json({ id: user.id, username: user.username, wins: user.wins });
});

app.post("/api/win", auth, (req, res) => {
  const db = readDB();
  const user = db.users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "账号不存在" });

  user.wins += 1;
  writeDB(db);
  res.json({ wins: user.wins });
});

app.get("/api/leaderboard", (req, res) => {
  const db = readDB();
  const list = [...db.users]
    .sort((a, b) => b.wins - a.wins || a.createdAt.localeCompare(b.createdAt))
    .slice(0, 100)
    .map((u, i) => ({ rank: i + 1, username: u.username, wins: u.wins }));
  res.json(list);
});

function cryptoRandomId() {
  return require("crypto").randomBytes(12).toString("hex");
}

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Minesweeper server running at http://localhost:${PORT}`);
});